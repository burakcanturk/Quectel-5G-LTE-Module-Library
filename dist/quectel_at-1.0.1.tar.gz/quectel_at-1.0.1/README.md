# Quectel-5G-LTE-Module-Library
This is a library for Quectel Modules.

<img src="https://market.samm.com/Data/EditorFiles/RM520N-GL-details-size.jpg" alt="Connections tab" width="300"/>

## Installation
```
pip install quectel_at
```

Thanks to[![GitHub](https://img.shields.io/badge/GitHub-black?style=flat&logo=GitHub)](https://github.com/iXenonN) @iXenonN
